import { createClient } from '@supabase/supabase-js';

const getValidUrl = (url: any): string => {
  const fallback = 'https://edbwnyjyunmnpnwilieq.supabase.co';
  if (!url || typeof url !== 'string' || url.trim() === '' || url === 'undefined') {
    return fallback;
  }
  
  try {
    // Basic validation to ensure it's a valid URL
    new URL(url);
    return url;
  } catch (e) {
    console.warn(`Invalid Supabase URL detected: "${url}". Falling back to default.`);
    return fallback;
  }
};

const supabaseUrl = getValidUrl(import.meta.env.VITE_SUPABASE_URL);
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY || 'sb_publishable_ZCd54VFkHLJZ91w69-FINw_OvW8LkkZ';

if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY) {
  console.info('Using fallback Supabase credentials. Ensure environment variables are set for production.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
