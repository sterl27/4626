/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useSpring, useTransform } from 'motion/react';
import { useGesture } from '@use-gesture/react';
import { 
  Battery, 
  Wifi, 
  Signal, 
  Search, 
  Calendar, 
  Cloud, 
  Music, 
  MessageCircle, 
  Camera, 
  Settings as SettingsIcon,
  ChevronRight,
  Plus,
  Sparkles,
  LogOut,
  Zap,
  Activity,
  Shield,
  Info
} from 'lucide-react';
import { LiquidChat } from '@/src/components/LiquidChat';
import { auth } from '@/src/lib/firebase';
import { FirebaseAuth } from '@/src/components/FirebaseAuth';
import { onAuthStateChanged, User as FirebaseUser, signOut } from 'firebase/auth';
import { useSettings } from '@/src/context/SettingsContext';

// 2026 Liquid Spring Config
const getLiquidSpring = (animationsEnabled: boolean) => ({
  type: animationsEnabled ? "spring" as const : "tween" as const,
  stiffness: 260,
  damping: 20,
  mass: 1,
  duration: animationsEnabled ? undefined : 0
});

// Liquid Haptics Engine
const useHaptics = () => {
  const { hapticsEnabled } = useSettings();
  
  return {
    pop: () => {
      if (hapticsEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(10);
      }
    },
    double: () => {
      if (hapticsEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate([10, 50, 10]);
      }
    },
    soft: () => {
      if (hapticsEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(5);
      }
    }
  };
};

const LiquidCard = ({ children, title, icon: Icon, color, delay = 0 }: any) => {
  const { animationsEnabled } = useSettings();
  const haptic = useHaptics();
  const liquidSpring = getLiquidSpring(animationsEnabled);
  const [ripples, setRipples] = useState<{ x: number, y: number, id: number }[]>([]);
  const cardRef = useRef<HTMLDivElement>(null);
  
  // Pinch-to-Zoom State
  const zoomScale = useMotionValue(1);
  const smoothZoom = useSpring(zoomScale, {
    stiffness: 300,
    damping: 30,
    mass: 1
  });

  useGesture({
    onPinch: ({ offset: [d] }) => {
      const s = 1 + d / 200;
      zoomScale.set(Math.max(1, Math.min(s, 2.5)));
    }
  }, {
    target: cardRef,
    eventOptions: { passive: false }
  });

  const addRipple = (e: React.PointerEvent) => {
    if (e.pointerType === 'touch' && !e.isPrimary) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const newRipple = { x, y, id: Date.now() };
    setRipples((prev) => [...prev, newRipple]);
    haptic.soft();
    
    setTimeout(() => {
      setRipples((prev) => prev.filter(r => r.id !== newRipple.id));
    }, 1000);
  };

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ ...liquidSpring, delay }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ 
        scale: 0.95,
        transition: { ...liquidSpring, stiffness: 400, damping: 15 }
      }}
      onPointerDown={addRipple}
      onTap={haptic.pop}
      className="glass-ultra-thin rounded-[32px] p-5 relative overflow-hidden group cursor-pointer touch-none"
    >
      {/* Liquid Ripples from Tap Point */}
      <AnimatePresence>
        {ripples.map((r) => (
          <motion.span
            key={r.id}
            initial={{ scale: 0, opacity: 0.4 }}
            animate={{ scale: 6, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            style={{
              position: 'absolute',
              left: r.x,
              top: r.y,
              width: 40,
              height: 40,
              marginLeft: -20,
              marginTop: -20,
              borderRadius: '50%',
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              pointerEvents: 'none',
              zIndex: 0,
              filter: 'blur(4px)'
            }}
          />
        ))}
      </AnimatePresence>

      {/* Zoomable Content Wrapper */}
      <motion.div style={{ scale: smoothZoom }} className="w-full h-full origin-center">
        {/* Parallax Content Layer 1: Icon */}
        <motion.div 
          whileHover={{ x: 5, y: -2 }}
          transition={liquidSpring}
          className="flex items-start justify-between mb-4 relative z-10"
        >
          <div className={`p-3 rounded-2xl ${color} shadow-lg`}>
            <Icon size={24} className="text-white" />
          </div>
          <Plus size={18} className="text-white/30 group-hover:text-white/60 transition-colors" />
        </motion.div>

        {/* Parallax Content Layer 2: Text */}
        <motion.div 
          whileHover={{ x: -3, y: 2 }}
          transition={liquidSpring}
          className="relative z-10"
        >
          <h3 className="text-white/50 text-xs font-semibold uppercase tracking-wider mb-1">{title}</h3>
          <div className="text-xl font-medium tracking-tight">{children}</div>
        </motion.div>
      </motion.div>
      
      <div className="absolute inset-0 bg-linear-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
    </motion.div>
  );
};

type AppView = 'home' | 'chat' | 'photos' | 'music' | 'settings' | 'weather' | 'calendar';

export default function App() {
  const { hapticsEnabled, setHapticsEnabled, animationsEnabled, setAnimationsEnabled } = useSettings();
  const haptic = useHaptics();
  const liquidSpring = getLiquidSpring(animationsEnabled);
  const [time, setTime] = useState(new Date());
  const [activeView, setActiveView] = useState<AppView>('home');
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <motion.div 
          animate={{ scale: [1, 1.1, 1], opacity: [0.4, 0.8, 0.4] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="w-16 h-16 rounded-full bg-emerald-500/20 blur-xl"
        />
      </div>
    );
  }

  if (!user) {
    return <FirebaseAuth />;
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    }).split(' ')[0];
  };

  const BackButton = () => (
    <motion.button
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      onClick={() => { haptic.pop(); setActiveView('home'); }}
      className="mb-6 flex items-center gap-2 text-white/40 hover:text-white transition-colors group"
    >
      <div className="p-2 rounded-full glass-ultra-thin group-hover:bg-white/10">
        <ChevronRight className="rotate-180 size-5" />
      </div>
      <span className="font-medium">Back</span>
    </motion.button>
  );

  const renderView = () => {
    switch (activeView) {
      case 'chat':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="h-full pb-24"
          >
            <BackButton />
            <LiquidChat />
          </motion.div>
        );
      case 'photos':
        return (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6 pb-24"
          >
            <BackButton />
            <h2 className="text-3xl font-bold tracking-tight">Photos</h2>
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <motion.div
                  key={i}
                  whileHover={{ scale: 1.05 }}
                  className="aspect-square rounded-3xl overflow-hidden glass-ultra-thin"
                >
                  <img 
                    src={`https://picsum.photos/seed/liquid${i}/400/400`} 
                    alt="Memory" 
                    className="w-full h-full object-cover opacity-80"
                    referrerPolicy="no-referrer"
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        );
      case 'music':
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-8 pb-24"
          >
            <BackButton />
            <div className="flex flex-col items-center text-center space-y-6 pt-4">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="w-64 h-64 rounded-full glass-thick p-1 shadow-2xl"
              >
                <img 
                  src="https://picsum.photos/seed/music/600/600" 
                  alt="Album Art" 
                  className="w-full h-full rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
              <div>
                <h2 className="text-2xl font-bold">Liquid Dreams</h2>
                <p className="text-white/40">Daft Punk</p>
              </div>
              <div className="flex items-center gap-8">
                <button onClick={haptic.pop} className="p-4 rounded-full glass-ultra-thin"><ChevronRight className="rotate-180" /></button>
                <button onClick={haptic.pop} className="p-6 rounded-full bg-white text-black"><Plus /></button>
                <button onClick={haptic.pop} className="p-4 rounded-full glass-ultra-thin"><ChevronRight /></button>
              </div>
            </div>
          </motion.div>
        );
      case 'settings':
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6 pb-24"
          >
            <BackButton />
            <h2 className="text-3xl font-bold tracking-tight mb-6">Settings</h2>
            
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-white/30 uppercase tracking-widest px-2">Experience</h3>
              
              <div 
                onClick={() => { haptic.pop(); setHapticsEnabled(!hapticsEnabled); }}
                className="glass-ultra-thin p-5 rounded-3xl flex items-center justify-between cursor-pointer hover:bg-white/5 transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-xl bg-emerald-500/10"><Zap size={20} className="text-emerald-400" /></div>
                  <span className="font-medium">Haptic Feedback</span>
                </div>
                <div className={`w-12 h-6 rounded-full p-1 transition-colors ${hapticsEnabled ? 'bg-emerald-500' : 'bg-white/10'}`}>
                  <motion.div 
                    animate={{ x: hapticsEnabled ? 24 : 0 }}
                    className="w-4 h-4 bg-white rounded-full shadow-lg"
                  />
                </div>
              </div>

              <div 
                onClick={() => { haptic.pop(); setAnimationsEnabled(!animationsEnabled); }}
                className="glass-ultra-thin p-5 rounded-3xl flex items-center justify-between cursor-pointer hover:bg-white/5 transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="p-2 rounded-xl bg-indigo-500/10"><Activity size={20} className="text-indigo-400" /></div>
                  <span className="font-medium">Fluid Animations</span>
                </div>
                <div className={`w-12 h-6 rounded-full p-1 transition-colors ${animationsEnabled ? 'bg-indigo-500' : 'bg-white/10'}`}>
                  <motion.div 
                    animate={{ x: animationsEnabled ? 24 : 0 }}
                    className="w-4 h-4 bg-white rounded-full shadow-lg"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-4">
              <h3 className="text-xs font-semibold text-white/30 uppercase tracking-widest px-2">System</h3>
              {[
                { label: 'Privacy & Security', icon: Shield, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
                { label: 'About LiquidUI', icon: Info, color: 'text-white/60', bg: 'bg-white/5' }
              ].map((item) => (
                <div 
                  key={item.label}
                  onClick={haptic.pop}
                  className="glass-ultra-thin p-5 rounded-3xl flex items-center justify-between cursor-pointer hover:bg-white/5 transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-xl ${item.bg}`}><item.icon size={20} className={item.color} /></div>
                    <span className="font-medium">{item.label}</span>
                  </div>
                  <ChevronRight size={18} className="text-white/20" />
                </div>
              ))}
            </div>
          </motion.div>
        );
      case 'weather':
        return (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-8 pb-24"
          >
            <BackButton />
            <div className="text-center space-y-2">
              <h2 className="text-5xl font-bold tracking-tighter">72°</h2>
              <p className="text-xl text-white/60">Cupertino, CA</p>
              <p className="text-cyan-400 font-medium">Mostly Sunny</p>
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[
                { time: 'Now', temp: '72°', icon: Cloud },
                { time: '1PM', temp: '74°', icon: Cloud },
                { time: '2PM', temp: '75°', icon: Cloud },
                { time: '3PM', temp: '73°', icon: Cloud },
              ].map((h) => (
                <div key={h.time} className="glass-ultra-thin p-4 rounded-2xl flex flex-col items-center gap-2">
                  <span className="text-xs text-white/40">{h.time}</span>
                  <h.icon size={20} className="text-white/80" />
                  <span className="font-bold">{h.temp}</span>
                </div>
              ))}
            </div>
          </motion.div>
        );
      case 'calendar':
        return (
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6 pb-24"
          >
            <BackButton />
            <h2 className="text-3xl font-bold tracking-tight">Calendar</h2>
            <div className="space-y-4">
              {[
                { time: '9:00 AM', title: 'Design Sync', desc: 'LiquidUI Team' },
                { time: '11:30 AM', title: 'Lunch with Jony', desc: 'The Glass House' },
                { time: '2:00 PM', title: 'Motion Review', desc: 'Studio A' },
              ].map((event) => (
                <div key={event.title} className="glass-ultra-thin p-5 rounded-3xl flex items-center gap-6">
                  <div className="text-sm font-bold text-orange-400 w-16">{event.time}</div>
                  <div>
                    <div className="font-bold">{event.title}</div>
                    <div className="text-sm text-white/40">{event.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        );
      default:
        return (
          <div className="space-y-8 pb-24">
            <header className="mb-10 space-y-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ ...liquidSpring, delay: 0.1 }}
              >
                <h1 className="text-[42px] font-bold tracking-tighter leading-none mb-2 text-vibrant">
                  Good Evening
                </h1>
                <p className="text-white/40 font-medium text-lg">Your liquid space is ready.</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ ...liquidSpring, delay: 0.2 }}
                className="relative group"
              >
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-emerald-400 transition-colors">
                  <Search size={18} />
                </div>
                <input 
                  type="text" 
                  placeholder="Search apps, files, or liquid space..."
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 transition-all glass-ultra-thin"
                />
              </motion.div>
            </header>

            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2" onClick={() => { haptic.pop(); setActiveView('weather'); }}>
                <LiquidCard title="Weather" icon={Cloud} color="bg-blue-500" delay={0.2}>
                  <div className="flex items-center justify-between">
                    <span>72° & Sunny</span>
                    <span className="text-white/40 text-sm">Cupertino</span>
                  </div>
                </LiquidCard>
              </div>
              
              <div onClick={() => { haptic.pop(); setActiveView('music'); }}>
                <LiquidCard title="Music" icon={Music} color="bg-pink-500" delay={0.3}>
                  <div className="truncate">Liquid Dreams</div>
                  <div className="text-white/40 text-sm">Daft Punk</div>
                </LiquidCard>
              </div>

              <div onClick={() => { haptic.pop(); setActiveView('calendar'); }}>
                <LiquidCard title="Calendar" icon={Calendar} color="bg-orange-500" delay={0.4}>
                  <div>Design Sync</div>
                  <div className="text-white/40 text-sm">9:00 AM</div>
                </LiquidCard>
              </div>

              <div className="col-span-2" onClick={() => { haptic.pop(); setActiveView('chat'); }}>
                <LiquidCard title="Intelligence" icon={MessageCircle} color="bg-cyan-500" delay={0.5}>
                  <div className="flex items-center justify-between">
                    <span>Ask LiquidUI...</span>
                    <Sparkles size={16} className="text-cyan-400" />
                  </div>
                </LiquidCard>
              </div>
            </div>

            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white/80">Recent Activity</h2>
                <ChevronRight size={20} className="text-white/20" />
              </div>
              <div className="space-y-3">
                {[
                  { icon: MessageCircle, name: "Messages", desc: "3 new notifications", color: "bg-emerald-500", view: 'chat' as const },
                  { icon: Camera, name: "Photos", desc: "Memories from yesterday", color: "bg-indigo-500", view: 'photos' as const },
                  { icon: SettingsIcon, name: "System", desc: "Update available", color: "bg-zinc-600", view: 'settings' as const }
                ].map((app, i) => (
                  <motion.div
                    key={app.name}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 + (i * 0.1) }}
                    onClick={() => { haptic.pop(); setActiveView(app.view); }}
                    className="glass-ultra-thin rounded-2xl p-4 flex items-center gap-4 hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <div className={`p-2.5 rounded-xl ${app.color}`}>
                      <app.icon size={20} className="text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-sm">{app.name}</div>
                      <div className="text-xs text-white/40">{app.desc}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>
          </div>
        );
    }
  };

  return (
    <div className="relative h-screen w-full bg-black flex flex-col font-sans select-none overflow-hidden">
      {/* Dynamic Refraction Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
            x: [0, 100, 0],
            y: [0, -50, 0]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute -top-1/2 -left-1/2 w-full h-full bg-indigo-600/20 rounded-full blur-[120px]" 
        />
        <motion.div 
          animate={{ 
            scale: [1.2, 1, 1.2],
            rotate: [0, -90, 0],
            x: [0, -100, 0],
            y: [0, 50, 0]
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-emerald-500/10 rounded-full blur-[120px]" 
        />
      </div>

      {/* Status Bar */}
      <div 
        className="px-8 pt-4 pb-2 flex justify-between items-center z-50"
      >
        <div className="flex items-center gap-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-sm font-semibold tracking-tight text-white/90 cursor-pointer"
            onClick={() => { haptic.pop(); setActiveView('home'); }}
          >
            {formatTime(time)}
          </motion.div>
          <button 
            onClick={() => { haptic.pop(); signOut(auth); }}
            className="p-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors group"
            title="Sign Out"
          >
            <LogOut size={14} className="text-white/40 group-hover:text-white/80" />
          </button>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Signal size={14} strokeWidth={2.5} className="text-white/80" />
            <Wifi size={14} strokeWidth={2.5} className="text-white/80" />
            <div className="relative" onClick={() => { haptic.double(); }}>
              <Battery size={18} strokeWidth={2} className="text-emerald-400" />
            </div>
          </div>
          <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-emerald-400 to-indigo-500 p-[1px]">
            <div className="w-full h-full rounded-full bg-[#050505] flex items-center justify-center overflow-hidden">
              <img 
                src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} 
                alt="User" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 px-6 pt-8 overflow-y-auto scrollbar-hide relative z-10">
        <AnimatePresence mode="wait">
          {renderView()}
        </AnimatePresence>
      </main>

      {/* Liquid Dock */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50">
        <motion.div 
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          transition={{ ...liquidSpring, delay: 0.8 }}
          className="glass-thick rounded-[40px] p-3 flex items-center gap-4 liquid-shadow"
        >
          {[
            { icon: MessageCircle, view: 'chat' as const },
            { icon: Camera, view: 'photos' as const },
            { icon: Music, view: 'music' as const },
            { icon: SettingsIcon, view: 'settings' as const }
          ].map((item, i) => (
            <motion.button
              key={i}
              whileHover={{ y: -12, scale: 1.18, transition: liquidSpring }}
              whileTap={{ scale: 0.82, transition: { ...liquidSpring, stiffness: 500, damping: 15 } }}
              onTapStart={haptic.soft}
              onClick={() => { haptic.pop(); setActiveView(item.view); }}
              className={`w-14 h-14 rounded-[24px] flex items-center justify-center transition-colors relative group overflow-hidden ${
                activeView === item.view ? 'bg-white/20' : 'bg-white/5 hover:bg-white/10'
              }`}
            >
              <motion.div
                className="absolute inset-0 bg-white/10 rounded-full pointer-events-none"
                initial={{ scale: 0, opacity: 0 }}
                whileHover={{ scale: 2.5, opacity: 1, transition: { duration: 0.8, ease: [0.23, 1, 0.32, 1] } }}
              />
              <item.icon size={24} className={`z-10 transition-colors ${activeView === item.view ? 'text-white' : 'text-white/80'}`} />
              
              {activeView === item.view && (
                <motion.div 
                  layoutId="dock-dot"
                  className="absolute -bottom-1 w-1 h-1 bg-cyan-400 rounded-full shadow-[0_0_10px_rgba(34,211,238,0.8)]" 
                />
              )}
            </motion.button>
          ))}
        </motion.div>
      </div>

      {/* Home Indicator */}
      <div 
        className="fixed bottom-2 left-1/2 -translate-x-1/2 w-32 h-1.5 bg-white/20 rounded-full z-50 cursor-pointer hover:bg-white/40 transition-colors" 
        onClick={() => { haptic.pop(); setActiveView('home'); }}
      />
    </div>
  );
}
