/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Sparkles, 
  User, 
  Bot, 
  Loader2, 
  Brain, 
  Globe, 
  MapPin, 
  Image as ImageIcon, 
  Mic, 
  Volume2,
  Settings2,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import ReactMarkdown from 'react-markdown';
import { geminiService } from '@/src/services/geminiService';
import { db, auth } from '@/src/lib/firebase';
import { collection, addDoc, query, orderBy, onSnapshot, limit, serverTimestamp } from 'firebase/firestore';
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";
import { LiquidLive } from '@/src/components/LiquidLive';

const liquidSpring = {
  type: "spring" as const,
  stiffness: 260,
  damping: 20,
  mass: 1
};

// Liquid Haptics Engine
const haptic = {
  pop: () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(10);
    }
  },
  soft: () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(5);
    }
  }
};

export function LiquidChat() {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [grounding, setGrounding] = useState<'none' | 'search' | 'maps'>('none');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [isLive, setIsLive] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(
      collection(db, `users/${auth.currentUser.uid}/messages`),
      orderBy('createdAt', 'asc'),
      limit(50)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(msgs);
    });
    return () => unsubscribe();
  }, []);

  const saveMessage = async (role: string, content: string) => {
    if (!auth.currentUser) return;
    await addDoc(collection(db, `users/${auth.currentUser.uid}/messages`), {
      role,
      content,
      createdAt: serverTimestamp()
    });
  };

  const onSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    haptic.pop();
    const userContent = input;
    setInput('');
    setIsLoading(true);
    await saveMessage('user', userContent);

    try {
      let responseText = "";
      
      // Check for image generation command
      if (userContent.toLowerCase().startsWith('/image ')) {
        const prompt = userContent.slice(7);
        const imageUrl = await geminiService.generateImage(prompt, imageSize);
        if (imageUrl) {
          responseText = `![Generated Image](${imageUrl})`;
        } else {
          responseText = "Failed to generate image.";
        }
      } 
      // Check for maps grounding
      else if (grounding === 'maps') {
        const result = await geminiService.searchMaps(userContent);
        responseText = result.text;
        if (result.grounding) {
          const links = result.grounding.map((g: any) => g.maps?.uri).filter(Boolean);
          if (links.length > 0) {
            responseText += "\n\n**Sources:**\n" + links.map((l: string) => `- [${l}](${l})`).join('\n');
          }
        }
      }
      // Pro Chat with Thinking/Search
      else {
        responseText = await geminiService.chatPro([...messages, { role: 'user', content: userContent }], thinking);
      }

      await saveMessage('assistant', responseText);
    } catch (error) {
      console.error("Chat Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTTS = async (text: string) => {
    haptic.soft();
    const audioUrl = await geminiService.textToSpeech(text);
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.play();
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          setTranscribing(true);
          try {
            const base64Audio = (reader.result as string).split(',')[1];
            const transcription = await geminiService.transcribe(base64Audio, 'audio/webm');
            if (transcription) {
              setInput(prev => prev + (prev ? ' ' : '') + transcription.trim());
              haptic.soft();
            }
          } catch (err) {
            console.error("Transcription Error:", err);
          } finally {
            setTranscribing(false);
          }
        };
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Recording Error:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <Card className="glass-ultra-thin border-none rounded-[32px] h-[700px] flex flex-col overflow-hidden liquid-shadow">
      <CardHeader className="border-b border-white/10 pb-4 flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2 text-vibrant">
          <Sparkles className="text-cyan-400 size-5" />
          Liquid Intelligence
        </CardTitle>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => { haptic.soft(); setIsLive(true); }}
            className="rounded-xl text-cyan-400 hover:bg-cyan-500/10"
            title="Live Session"
          >
            <Zap size={18} />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => { haptic.soft(); setThinking(!thinking); }}
            className={`rounded-xl transition-all ${thinking ? 'bg-indigo-500/20 text-indigo-400' : 'text-white/40'}`}
            title="Thinking Mode"
          >
            <Brain size={18} />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => { haptic.soft(); setGrounding(grounding === 'search' ? 'none' : 'search'); }}
            className={`rounded-xl transition-all ${grounding === 'search' ? 'bg-emerald-500/20 text-emerald-400' : 'text-white/40'}`}
            title="Search Grounding"
          >
            <Globe size={18} />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => { haptic.soft(); setGrounding(grounding === 'maps' ? 'none' : 'maps'); }}
            className={`rounded-xl transition-all ${grounding === 'maps' ? 'bg-orange-500/20 text-orange-400' : 'text-white/40'}`}
            title="Maps Grounding"
          >
            <MapPin size={18} />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 p-0 overflow-hidden relative">
        <AnimatePresence>
          {isLive && <LiquidLive onClose={() => setIsLive(false)} />}
        </AnimatePresence>
        
        <ScrollArea className="h-full p-6">
          <div className="space-y-6">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-[300px] text-center space-y-4">
                <div className="p-4 rounded-full bg-white/5 border border-white/10">
                  <Bot className="size-8 text-white/40" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">How can I help you today?</h3>
                  <p className="text-sm text-white/40 max-w-[240px]">
                    I'm your Liquid AI assistant, ready to flow through your ideas.
                  </p>
                  <div className="flex gap-2 justify-center mt-4">
                    <span className="text-[10px] px-2 py-1 rounded-full bg-white/5 text-white/40 border border-white/10">/image [prompt]</span>
                    <span className="text-[10px] px-2 py-1 rounded-full bg-white/5 text-white/40 border border-white/10">Pro 3.1</span>
                  </div>
                </div>
              </div>
            )}
            
            <AnimatePresence initial={false}>
              {messages.map((m) => (
                <motion.div
                  key={m.id}
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={liquidSpring}
                  className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {m.role !== 'user' && (
                    <div className="size-8 rounded-full bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center shrink-0">
                      <Bot className="size-4 text-cyan-400" />
                    </div>
                  )}
                  
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 relative group ${
                    m.role === 'user' 
                      ? 'bg-white/10 text-white rounded-tr-none' 
                      : 'glass-thick text-white/90 rounded-tl-none'
                  }`}>
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{m.content}</ReactMarkdown>
                    </div>
                    {m.role === 'assistant' && (
                      <button 
                        onClick={() => handleTTS(m.content)}
                        className="absolute -right-8 top-0 opacity-0 group-hover:opacity-100 transition-opacity p-1 text-white/20 hover:text-white"
                      >
                        <Volume2 size={14} />
                      </button>
                    )}
                  </div>

                  {m.role === 'user' && (
                    <div className="size-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center shrink-0">
                      <User className="size-4 text-white/60" />
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            
            {isLoading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-3 justify-start"
              >
                <div className="size-8 rounded-full bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center shrink-0">
                  <Loader2 className="size-4 text-cyan-400 animate-spin" />
                </div>
                <div className="glass-thick rounded-2xl rounded-tl-none px-4 py-3">
                  <div className="flex gap-1">
                    <span className="w-1 h-1 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1 h-1 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1 h-1 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </ScrollArea>
      </CardContent>

      <CardFooter className="p-6 pt-2 flex flex-col gap-3">
        <div className="flex items-center gap-2 w-full">
          <div className="flex gap-1 bg-white/5 p-1 rounded-xl border border-white/10">
            {(['1K', '2K', '4K'] as const).map(size => (
              <button
                key={size}
                onClick={() => { haptic.soft(); setImageSize(size); }}
                className={`text-[10px] px-2 py-0.5 rounded-lg transition-all ${imageSize === size ? 'bg-white/20 text-white' : 'text-white/40 hover:text-white/60'}`}
              >
                {size}
              </button>
            ))}
          </div>
          <div className="flex-1" />
          <Button 
            variant="ghost" 
            size="icon" 
            className={`rounded-xl transition-all ${isRecording ? 'text-red-400 bg-red-500/10' : 'text-white/40 hover:bg-white/5'}`}
            onMouseDown={() => { haptic.soft(); startRecording(); }}
            onMouseUp={stopRecording}
            onMouseLeave={stopRecording}
            title="Hold to speak"
          >
            {transcribing ? <Loader2 size={18} className="animate-spin text-cyan-400" /> : <Mic size={18} />}
          </Button>
        </div>

        <form onSubmit={onSend} className="flex w-full items-center gap-2 relative">
          <div className="relative flex-1">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={isRecording ? "Listening..." : transcribing ? "Transcribing..." : "Type your message or /image..."}
              className={`bg-white/5 border-white/10 rounded-2xl h-12 pl-4 pr-12 focus-visible:ring-cyan-500/50 transition-all ${isRecording ? 'border-red-500/50 ring-1 ring-red-500/20' : ''}`}
            />
            {isRecording && (
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex gap-1">
                <motion.span animate={{ height: [4, 12, 4] }} transition={{ repeat: Infinity, duration: 0.5 }} className="w-1 bg-red-500 rounded-full" />
                <motion.span animate={{ height: [8, 4, 8] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.1 }} className="w-1 bg-red-500 rounded-full" />
                <motion.span animate={{ height: [4, 10, 4] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.2 }} className="w-1 bg-red-500 rounded-full" />
              </div>
            )}
          </div>
          <Button 
            type="submit" 
            size="icon" 
            disabled={isLoading || !input.trim()}
            onMouseDown={haptic.soft}
            className="absolute right-1.5 top-1.5 size-9 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black transition-all"
          >
            <Send className="size-4" />
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
}
