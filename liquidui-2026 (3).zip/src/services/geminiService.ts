import { GoogleGenAI, Type, ThinkingLevel, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const geminiService = {
  // Pro Chat with Thinking
  async chatPro(messages: any[], thinking: boolean = false) {
    const model = "gemini-3.1-pro-preview";
    const response = await ai.models.generateContent({
      model,
      contents: messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      })),
      config: {
        thinkingConfig: thinking ? { thinkingLevel: ThinkingLevel.HIGH } : undefined,
        tools: [{ googleSearch: {} }, { urlContext: {} }]
      }
    });
    return response.text;
  },

  // Fast Chat
  async chatFast(prompt: string) {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite-preview",
      contents: prompt,
    });
    return response.text;
  },

  // Image Generation
  async generateImage(prompt: string, size: "1K" | "2K" | "4K" = "1K") {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-image-preview",
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          imageSize: size,
          aspectRatio: "1:1"
        }
      }
    });
    
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  },

  // Maps Grounding
  async searchMaps(query: string, location?: { lat: number, lng: number }) {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: query,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: location ? {
            latLng: {
              latitude: location.lat,
              longitude: location.lng
            }
          } : undefined
        }
      }
    });
    return {
      text: response.text,
      grounding: response.candidates?.[0]?.groundingMetadata?.groundingChunks
    };
  },

  // TTS
  async textToSpeech(text: string, voice: string = 'Kore') {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice as any },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return `data:audio/wav;base64,${base64Audio}`;
    }
    return null;
  },

  // Transcription
  async transcribe(base64Audio: string, mimeType: string = 'audio/wav') {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        { text: "Transcribe this audio exactly." },
        { inlineData: { data: base64Audio, mimeType } }
      ]
    });
    return response.text;
  }
};
