# LiquidUI 2026

LiquidUI 2026 is a high-fidelity, futuristic mobile interface concept designed for the next generation of fluid, tactile, and intelligent user experiences. Built with **React**, **Tailwind CSS**, and **Framer Motion**, it embodies the "Liquid Design System"—a vision of UI that behaves like mercury: responsive, weighted, and effortlessly smooth.

## ✨ Key Features

### 💧 Liquid Design System
- **Refractive Glassmorphism**: Ultra-thin glass surfaces with real-time backdrop blurring and subtle refractive borders.
- **Spring-Driven Motion**: Every interaction is powered by a custom `liquidSpring` configuration, ensuring 120Hz-ready, buttery-smooth transitions.
- **Bento Grid Layout**: A highly organized, responsive grid of "Liquid Cards" that adapt to content and user presence.

### 🧠 Liquid Intelligence
- **AI-Native Core**: A built-in "Liquid Intelligence" chat interface powered by **Gemini 1.5 Flash** via the **Vercel AI SDK**.
- **Contextual Awareness**: The AI assistant is tuned to the LiquidUI design philosophy, helping you navigate and design fluid spaces.

### 🖐️ Tactile Haptics
- **Physical Feedback**: Integrated haptic engine using `navigator.vibrate` to provide "pops" on activation and "pulses" for system status.
- **Mercury Ripples**: Interactive touch ripples that expand like liquid droplets when cards or dock icons are tapped.

### 📱 Immersive Shell
- **Omni-Search**: A glassmorphic search bar integrated into the home header for instant access to apps, files, and intelligence.
- **Dynamic Status Bar**: Real-time clock, signal strength, and a "breathing" battery indicator with charging simulations.
- **Liquid Dock**: A floating, elevated navigation bar with high-fidelity hover elevations and active indicators.
- **Refraction Background**: Ambient, animated light sources that create a sense of depth and atmosphere behind the UI.

## 🛠️ Tech Stack

- **Frontend**: React 19, Vite, Framer Motion (motion/react), Lucide Icons, @use-gesture/react.
- **Backend**: Express.js (Custom Server), Vercel AI SDK, Supabase (Auth & Data).
- **Styling**: Tailwind CSS 4.0 with custom Liquid theme variables.
- **AI**: Google Gemini 1.5 Flash.

## 🚀 Getting Started

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Supabase Setup**:
   - Create a project at [supabase.com](https://supabase.com).
   - Enable **Email Auth** and **Google Auth** in the Authentication settings.
   - For Google Auth, you'll need to create a project in the [Google Cloud Console](https://console.cloud.google.com) and get your **Client ID** and **Client Secret**.
   - Add your app's URL (e.g., `https://your-app.run.app`) to the **Authorized redirect URIs** in Google Cloud and the **Redirect URLs** in Supabase.

3. **Environment Variables**:
   - Create a `.env` file based on `.env.example`.
   - Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY`.
   - Set `GEMINI_API_KEY` for the AI features.

4. **Run Development Server**:
   ```bash
   npm run dev
   ```

## 🎨 Design Philosophy

LiquidUI is built on three pillars:
1. **Fluidity**: Interfaces should never "snap"; they should flow.
2. **Tactility**: Digital elements should feel like they have physical weight and surface tension.
3. **Intelligence**: AI shouldn't be a feature; it should be the atmosphere.

---

*Designed for the year 2026. Built today.*
