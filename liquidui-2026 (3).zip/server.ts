import express from "express";
import { createServer as createViteServer } from "vite";
import { google } from "@ai-sdk/google";
import { streamText } from "ai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // AI Chat Route
  app.post("/api/chat", async (req, res) => {
    const { messages } = req.body;
    
    try {
      const result = streamText({
        model: google("gemini-1.5-flash") as any,
        messages,
        system: "You are LiquidUI, an advanced 2026 Apple iOS UI/UX design intelligence. Your tone is calm, confident, and poetic. You help users design fluid, mercury-like interfaces.",
      });

      result.pipeTextStreamToResponse(res);
    } catch (error) {
      console.error("Chat Error:", error);
      res.status(500).json({ error: "Failed to generate response" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
